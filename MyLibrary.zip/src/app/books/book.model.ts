export class Book {
    $key: string;
    isbn: string;
    title: string;
    description: string;
    author: string;
    category: string;
    rating: string;
    allotedTo: string;
    allotedTill: string;
    thumbnail: string;
    likedBy: string[];
    review: { comment: string, user: string }[];
    isAvailable: boolean;


}
