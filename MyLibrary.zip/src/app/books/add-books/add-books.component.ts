import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs/Observable";
import { Response } from "@angular/http";
import { BookService } from '../books.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Book } from '../book.model';
import { ToastrService } from 'ngx-toastr';




@Component({
  selector: 'app-add-books',
  templateUrl: './add-books.component.html',
  styleUrls: ['./add-books.component.css']
})
export class AddBooksComponent implements OnInit {

  isbn: string;
  rating = "NA";
  book: Book;
  Books = [];
  bookForm: FormGroup;
  bookThumbnail: string;


  prop: boolean;

  constructor(private _bookservice: BookService, private toastr: ToastrService) {



    //     this.book={id:1,
    //       name:"Harry Potter and the Philosopher's Stone",
    // author:"J.K. Rowling",
    // thumbnail:"../assets/img/book.png",
    // desciption:"When the first novel of the series, Harry Potter and the Philosopher's Stone (published in America and other countries as Harry Potter and the Sorcerer's Stone) opens, it is apparent that some significant event has taken place in the Wizarding World – an event so very remarkable, even Muggles (non-magical people) notice signs of it. The full background to this event and Harry Potter's past is revealed gradually through the series. After the introductory chapter, the book leaps forward to a time shortly before Harry Potter's eleventh birthday, and it is at this point that his magical background begins to be revealed.",
    // votes:"4"};

  }

  ngOnInit() {
    this.prop = false;
    this.bookThumbnail = "../assets/img/book.png";
    this.bookForm = new FormGroup(
      {
        "booktitle": new FormControl(null, Validators.required),
        "bookauthor": new FormControl(null, Validators.required),
        "bookdescription": new FormControl(null, Validators.required),
        "bookcategory": new FormControl(null, Validators.required),
        "bookrating": new FormControl(null, Validators.required),
        "bookthumbnail": new FormControl(this.bookThumbnail, Validators.required)


      }


    );



  }


  getISBNData() {
    if (this.isbn) {

      this._bookservice.getISBNDetails(this.isbn).subscribe
        (
        (response: Response) => {
          const data = response;

          if (data['totalItems'] != 0) {


            try {
              this.bookForm = new FormGroup(
                {
                  "booktitle": new FormControl((data['items'][0].volumeInfo.title !== undefined) ? data['items'][0].volumeInfo.title : "", Validators.required),
                  "bookauthor": new FormControl((data['items'][0].volumeInfo.authors !== undefined) ? data['items'][0].volumeInfo.authors : "", Validators.required),
                  "bookdescription": new FormControl((data['items'][0].volumeInfo.description !== undefined) ? data['items'][0].volumeInfo.desciption : "", Validators.required),
                  "bookcategory": new FormControl((data['items'][0].volumeInfo.categories !== undefined) ? data['items'][0].volumeInfo.categories[0] : "", Validators.required),
                  "bookrating": new FormControl((data['items'][0].volumeInfo.averageRating !== undefined) ? data['items'][0].volumeInfo.averageRating : "", Validators.required),
                  "bookthumbnail": new FormControl((data['items'][0].volumeInfo.imageLinks !== undefined) ? data['items'][0].volumeInfo.imageLinks['smallThumbnail'] : "", Validators.required)


                }
              );
              this.bookThumbnail = data['items'][0].volumeInfo.imageLinks['smallThumbnail'];
            }
            catch (e) {
              this.toastr.error("Seems like some of the required deatils not available for the books please try some other ISBN.", "Error!");
            }





            this.prop = true;
          }
          else {
            this.bookThumbnail = "../assets/img/book.png";
            this.toastr.error("Unable to find book of this ISBN! Please add manually.", "Error!");

          }
        },
        (error) => {
          this.bookThumbnail = "../assets/img/book.png";
          this.prop = true;
          this.toastr.error("Unable to find book of this ISBN! Please add manually", "Error!");
        }
        );
    }
    else {

      this.toastr.error("Please provide the ISBN or Book Title!", "Error!");
    }
  }








  saveBook() {


    // this.book={isbn:this.isbn,
    //   title:this.bookForm.value.booktitle,
    //   description:this.bookForm.value.bookdescription,
    //   author:this.bookForm.value.bookauthor.toString(),
    //   category:this.bookForm.value.bookcategory,
    //   rating:this.bookForm.value.bookrating,
    //   allotedTo:'',
    //   allotedTill:'',
    //   thumbnail:this.bookForm.value.bookthumbnail,
    //   likedBy:['admin'],
    //   isAvailable:true
    //  };
    if (this.bookForm.valid) {
      this.book = new Book();
      this.book.isbn = this.isbn,
        this.book.title = this.bookForm.value.booktitle,
        this.book.description = this.bookForm.value.bookdescription,
        this.book.author = this.bookForm.value.bookauthor.toString(),
        this.book.category = this.bookForm.value.bookcategory,
        this.book.rating = this.bookForm.value.bookrating,
        this.book.allotedTo = '',
        this.book.allotedTill = '',
        this.book.thumbnail = this.bookThumbnail
      this.book.likedBy = [''];
      this.book.isAvailable = true;
      this.book.review = [{ comment: "", user: "" }];



      this._bookservice.saveBookToDB(this.book).subscribe(
        (response) => {
          console.log(response);
          this.toastr.success("Book added successfully!.", "Success");
        },
        (error) => {
          console.log(error);
          this.toastr.error("Something went wrong!.", "Error");
        }
      );
      this.prop = false;
      this.isbn = "";
    }

    else {
      this.toastr.error("Please provide all the information!", "Error!");
    }
  }


}
