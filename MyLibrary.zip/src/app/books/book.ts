export interface IBook {
  likedBy: string[];
  isbn: string;
  title: string;
  description: string;
  author: string;
  category: string;
  rating: string;
  allotedTo: string;
  allotedTill: string;
  thumbnail: string;
}