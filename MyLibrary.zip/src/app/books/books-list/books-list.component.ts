import { Component, OnInit } from '@angular/core';
import { BookService } from '../books.service';
import { Book } from '../book.model';
import { AuthService } from '../../auth/auth.service';
import { ToastrService } from 'ngx-toastr';




@Component({
  selector: 'app-books-list',
  templateUrl: './books-list.component.html',
  styleUrls: ['./books-list.component.css']
})
export class BooksListComponent implements OnInit {

  public Books: Book[];
 // public Books = [];
  BooksNew = [];
  SelectedFilter='title';
  SelectedSearch='title'
  public book: Book;
  serachByParam;
  
  data;

  constructor(public _bookService: BookService,private _authService:AuthService,private tostr: ToastrService) {
  
  }

  getBookList()
  {
    this._bookService.getData().snapshotChanges().subscribe(
        response=>
        {             
          
          
    this.Books = [];
          response.forEach(element => {
            var y = element.payload.toJSON();
            y["$key"] = element.key;
            this.Books.push(y as Book);
        });
        
      
  
      });
     
   
  }

  SelectedValueToSearch(data)
  {
 this.SelectedSearch=data.value;
  }

  
  SelectedValueToFilter(data)
  {
 this.SelectedFilter=data.value;
  }
 

  ngOnInit() {  
  
    this.getBookList();

  }

  AddToWishlist(key:string,bookObj:Book)
  {

    let dt=[];
    for(let i in bookObj.likedBy)
    {
      
      dt.push(bookObj.likedBy[i]);
    }
   // dt=bookObj.likedBy;
   if(dt.indexOf(this._authService.getuserEmail()) === -1){
    dt.push(this._authService.getuserEmail());

   
   }
   bookObj.likedBy=dt;
    
    this._bookService.updateBook(bookObj, key);
    this.tostr.success("Book has been added to Favorites!","Success!");
    
  }


  DeleteBook(key:string)
  {
    if(confirm("Are you sure to delete?"))
    {
    this._bookService.deleteBook(key);
    this.tostr.info("Successfully Deleted Book!","Book Deleted!");
    }
   
    
  }

  

}
