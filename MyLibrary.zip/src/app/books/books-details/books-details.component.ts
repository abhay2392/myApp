import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BookService } from '../books.service';
import { Book } from '../book.model';
import { AuthService } from '../../auth/auth.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-books-details',
  templateUrl: './books-details.component.html',
  styleUrls: ['./books-details.component.css']
})
export class BooksDetailsComponent implements OnInit {

  disableAllocator=true;
  btnContent: string = "Allocate Me";
  btnClass: string = "btn btn-info";

  public name="dataFrom";
  key: string;
  Books = [];
  public book: Book;
  AllocateTill: string;
  btnReturnVisibility:boolean= false;
  user: string;
  constructor(private route: ActivatedRoute, private _bookService: BookService, private _authservice: AuthService, private tostr: ToastrService) {

  }


  ngOnInit() {

    
    this.book = new Book();
    this.key = this.route.snapshot.params['key'];
    this.user = this._authservice.getuserEmail();
    this._bookService.getBookDetails().snapshotChanges().subscribe(
      response => {


        response.forEach(element => {
          var y = element.payload.toJSON();
          y["$key"] = element.key;

          if (y["$key"] == this.key) {
            this.book = y as Book;
           
            this.AllocateTill=this.book.allotedTill;
            if (this.book.isAvailable == false && this.book.allotedTo == this.user) {

              this.btnClass = 'btn btn-danger';
              this.btnContent = "Extend Book";
              this.btnReturnVisibility=true;
            }


           
            if(this.book.allotedTo != this.user && this.book.allotedTo!="")
            {
              this.disableAllocator=false;
            }

          }
        });



      });








  }

usersBooksCount;
  getUsersBooksCount()
  {
    
  }

  ReturnBook() {
    
    this.book.allotedTo = "";
    this.book.allotedTill = "";
    this.book.isAvailable = true;
    this.btnContent = "Allocate Me";
  this.btnClass = "btn btn-info";
  this.btnReturnVisibility=false;
  this.tostr.success("Book has been returned!","Success!");
           
    this._bookService.updateBook(this.book, this.key);
  }

  AllocateBook() {

   if(this.AllocateTill)
   {
    
    
    this.user = this._authservice.getuserEmail();
    
    this._bookService.getBooksFromDB().subscribe(
      (response) => {      
        this.usersBooksCount=0;
        for (let i in response) {
          if(response[i].allotedTo==this.user)
          {
            this.usersBooksCount+=1
        
        }
        }

        this._bookService.GetMaxBookCount().subscribe(
          (response)=>
          {
            if(this.btnContent=="Extend Book")           

            {
           
            this.book.allotedTo = this.user;
            this.book.allotedTill = this.AllocateTill.toString();
            this.book.isAvailable = false;           
            this._bookService.updateBook(this.book, this.key);
            this._authservice.updateNotification();
            this.tostr.success("Book has been allocated to you till:"+this.book.allotedTill,"Success!");
            }else if(this.usersBooksCount < response)
              {
                this.book.allotedTo = this.user;
                this.book.allotedTill = this.AllocateTill.toString();
                this.book.isAvailable = false;           
                this._bookService.updateBook(this.book, this.key);
                this.tostr.success("Book has been allocated to you till:"+this.book.allotedTill,"Success!");
                this._authservice.updateNotification();
              }
              
            
            else
            {
              this.tostr.error("You have already reached the limit of max. books please return some books to get new books.","Error");
            }
          },
          (error)=>console.log(error)
        );
        
       

       
      },
      (error) => (console.log(error))

    );
   
  }
  else{
    this.tostr.error("Please provide a date!","Error");
            
  }
}

}
