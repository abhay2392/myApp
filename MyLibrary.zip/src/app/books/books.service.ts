import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import { IBook } from "./book";
import { AuthService } from "../auth/auth.service";
import { auth } from "firebase";
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database'
import { Book } from "./book.model";
import { templateJitUrl } from "@angular/compiler";


@Injectable()
export class BookService {
    bookList = [];
    dataList: AngularFireList<any>;
    Books = [];
    public searchFilterList = [
        'title',
        'author',
        'category',
        'allotedTo',

    ];
    public sortFilterList = [
        'title',
        'author',
        'category',
        'allotedTo',
        'allotedTill'

    ];
    isbn = "";//9780136019701;
    firebaseApiUrl = "https://mylibraryapp-49d0f.firebaseio.com/";
    isbnUrl = 'https://www.googleapis.com/books/v1/volumes?q=' + this.isbn;//"../assets/data.json"; //
    constructor(private http: HttpClient, private _authService: AuthService, private firebase: AngularFireDatabase) {
        this.getData();


    }


    getData() {
        this.dataList = this.firebase.list('book');

        return this.dataList;
    }






    addBook(book: Book) {
        this.dataList.push({
            isbn: book.isbn,
            title: book.title,
            description: book.description,
            author: book.author,
            category: book.category,
            rating: book.rating,
            allotedTo: book.allotedTo,
            allotedTill: book.allotedTill,
            thumbnail: book.thumbnail

        });
    }



    updateBook(book: Book, $key: string) {
        console.log(book);
        this.dataList.update($key,
            {
                isbn: book.isbn,
                title: book.title,
                description: book.description,
                author: book.author,
                category: book.category,
                rating: book.rating,
                allotedTo: book.allotedTo,
                allotedTill: book.allotedTill,
                thumbnail: book.thumbnail,
                isAvailable: book.isAvailable,
                likedBy: book.likedBy,
                review: book.review

            });
    }

    deleteBook($key: string) {
        this.dataList.remove($key);
        this.getData();

    }

    book;
    getBookDetails() {


        return this.dataList;

        // return this.book;

    }


    getISBNDetails(isbn: string) {

        return this.http.get(this.isbnUrl + isbn);
    }

    saveBookToDB(book) {
        const token = this._authService.getAuthKey();
        return this.http.post(this.firebaseApiUrl + "book.json?auth=" + token, book);
    }

    getBooksFromDB(): Observable<Book[]> {
        const token = this._authService.getAuthKey();
        return this.http.get<Book[]>(this.firebaseApiUrl + "book.json?auth=" + token);
    }

    createUserObject() {
        const token = this._authService.getAuthKey();
        //return this.http.post(this.firebaseApiUrl+"book.json?auth="+token,);
    }

    SetMaxBookCount(count) {
        const token = this._authService.getAuthKey();

        return this.http.put(this.firebaseApiUrl + "MaxCount.json?auth=" + token, count);

    }

    GetMaxBookCount() {
        const token = this._authService.getAuthKey();
        return this.http.get(this.firebaseApiUrl + "MaxCount.json?auth=" + token);

    }


    getSortList() {
        let tempList = [];
        if (!this._authService._isAdmin) {
            tempList = this.sortFilterList.slice(0, 3);
            return tempList;
        }
        return this.sortFilterList;
    }

    getSearchList() {
        let tempList = [];
        if (!this._authService._isAdmin) {
            tempList = this.searchFilterList.slice(0, 3);
            return tempList;
        }
        return this.searchFilterList;
    }




}
