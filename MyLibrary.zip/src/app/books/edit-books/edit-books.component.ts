import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs/Observable";
import { BookService } from '../books.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Book } from '../book.model';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../../auth/auth.service';
import { ToastrService } from 'ngx-toastr';
import { validateConfig } from '@angular/router/src/config';


@Component({
  selector: 'app-edit-books',
  templateUrl: './edit-books.component.html',
  styleUrls: ['./edit-books.component.css']
})



export class EditBooksComponent implements OnInit {

  isbn: string;
  book :Book;
  editbook: Book;
  editBookForm: FormGroup;
  bookThumbnail: string;
  key: string;
  user: string;

  constructor(private _bookservice: BookService, private route: ActivatedRoute, private _authService: AuthService, private toastr:ToastrService ) {

    this.editBookForm= new FormGroup(
      {
        "booktitle":new FormControl(null),
        "bookauthor":new FormControl(null),
        "bookdescription":new FormControl(null),
        "bookcategory":new FormControl(null),
        "bookrating":new FormControl(null),
        "bookthumbnail":new FormControl(null)


      }
     
    );
  }

  ngOnInit() {

    this.editbook = new Book();
    this.key = this.route.snapshot.params['key'];


    this.user = this._authService.getuserEmail();
    this._bookservice.getBookDetails().snapshotChanges().subscribe(
      response => {


        response.forEach(element => {
          var y = element.payload.toJSON();
          y["$key"] = element.key;

          if (y["$key"] == this.key) {
            this.editbook = y as Book;
            console.log(this.editbook);

            this.editBookForm = new FormGroup(
              {
                "booktitle": new FormControl(this.editbook.title,Validators.required),
                "bookauthor": new FormControl( this.editbook.author,Validators.required ),
                "bookdescription": new FormControl(this.editbook.description,Validators.required),
                "bookcategory": new FormControl(this.editbook.category,Validators.required),
                "bookrating": new FormControl( this.editbook.rating ,Validators.required),
                "bookthumbnail": new FormControl( this.editbook.thumbnail,Validators.required),
              }

            );
            this.bookThumbnail = this.editbook.thumbnail;
          }
        });



      });
  }


  EditBook() {
    if(this.editBookForm.valid)
    {

    
    
    this.book= new Book();
   
      this.book.isbn= this.editbook.isbn;
      this.book.title=this.editBookForm.value.booktitle;
      this.book.description= this.editBookForm.value.bookdescription;
      this.book.author=this.editBookForm.value.bookauthor.toString();
      this.book.category= this.editBookForm.value.bookcategory;
      this.book.rating= this.editBookForm.value.bookrating;
      this.book.allotedTo= this.editbook.allotedTo;
      this.book.allotedTill= this.editbook.allotedTill;
      this.book.thumbnail= this.editBookForm.value.bookthumbnail;
      this.book.likedBy= this.editbook.likedBy;
      this.book.isAvailable= this.editbook.isAvailable;
      this.book.review=this.editbook.review;
 

  


   this._bookservice.updateBook(this.book, this.key);
   this.toastr.success("Book updated successfully!.","Success!");
    }
    else{
      this.toastr.error("Please provide all the information!.","Error!");
    }
  }



}
