import { Component, OnInit, Input, OnChanges, SimpleChange, SimpleChanges, AfterViewInit } from '@angular/core';
import { Book } from '../book.model';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BookService } from '../books.service';
import { AuthService } from '../../auth/auth.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-review-book',
  templateUrl: './review-book.component.html',
  styleUrls: ['./review-book.component.css']
})
export class ReviewBookComponent implements OnInit,OnChanges {

  @Input() public bookReview:Book;
  constructor(private _bookService:BookService, private _authService:AuthService,private toastr:ToastrService) { }

  key:string;
  book:Book;
 reviewForm:FormGroup;
  review:any[]=[];

  ngOnInit() {
    
    this.reviewForm = new FormGroup(
      {
        "review": new FormControl(null,Validators.required)
      }
    );

    
  }

  SubmitReview()
  {
    if(this.reviewForm.valid)
    {
    this.review.push({comment:this.reviewForm.value.review,user:this._authService.userEmail});
    this.book.review=this.review;
this._bookService.updateBook(this.book,this.book.$key);
this.reviewForm.reset();
this.toastr.success("Review added!","Success!");
    }
    else{

    this.toastr.error("Please provide some comments!","Error!");
    }
  }

 


  ngOnChanges(changes: SimpleChanges) {
    if (changes['bookReview']) {
      
      
      this.bookReview.review;
     
if( this.bookReview.review!=undefined)
{
  this.review=[];
  this.book=this.bookReview;
      for(let i in this.bookReview.review)
      {
        
        let revObj={comment:this.bookReview.review[i]['comment'], user: this.bookReview.review[i]['user']};
        if(revObj.user!=="")
        {
        this.review.push(revObj);
        }
        
      }
      
    }
  }
  }

}
