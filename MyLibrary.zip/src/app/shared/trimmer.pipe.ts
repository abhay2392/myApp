import { PipeTransform, Pipe } from "@angular/core";
@Pipe({
    name: "Trimmer"
})

export class TrimmerPipe implements PipeTransform {
    transform(value: any, limit: number) {
        if (value.length > limit) {
            return value.substring(0, limit) + "...";
        }
        return value;
    }
}