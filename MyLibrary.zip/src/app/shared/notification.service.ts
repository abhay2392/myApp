import { Injectable } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { BookService } from '../books/books.service';

@Injectable()
export class NotificationService {

  Books;
  user;
  constructor(private _authService:AuthService, private _bookService:BookService) { }

  GetNotifications(){
    this.user = this._authService.getuserEmail();
    var count=0;
    this._bookService.getData().snapshotChanges().subscribe(
      (response) => {       

        
          this.Books = [];
          response.forEach(element => {
            var y = element.payload.toJSON();
            y["$key"] = element.key;
            if(y['allotedTo']==this.user)
            { 
              count++;
           
            }      
        });
        return count;
      },
      (error) => (console.log(error)));
    return count;
  }

}
