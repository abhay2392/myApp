import { PipeTransform, Pipe } from "@angular/core";
import { Book } from "../books/book.model";

@Pipe
    (
    {
        name: "SearchBy",
        pure: false
    }
    )

export class SearchByPipe implements PipeTransform {
    transform(book: any, value: string, filter: string) {

        let Books = [];


        //  return book.filter(item => item);

        if (value == undefined) {
            return book;

        } else {
            for (let i in book) {


                if (book[i][filter].toLowerCase().includes(value.toLowerCase())) {
                    Books.push(book[i]);
                }
            }

        }

        return (Books.length == 0) ? book : Books;



    }

} 