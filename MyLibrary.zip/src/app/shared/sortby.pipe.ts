import { PipeTransform, Pipe } from "@angular/core";
import { Book } from "../books/book.model";

@Pipe
    (
    {
        name: "SortBy",
        pure: false
    }
    )

export class SortByPipe implements PipeTransform {
    transform(book: any, filter: string) {



        //  return book.filter(item => item);
        if (book) {
            if (filter != undefined) {
                book.sort(function (a, b) {
                    var x = a[filter].toLowerCase();
                    var y = b[filter].toLowerCase();
                    if (x < y) { return -1; }
                    if (x > y) { return 1; }
                    return 0;
                });

            }
        }

        return book;



    }

} 