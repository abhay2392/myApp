import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { BookService } from '../books/books.service';
import { BooksComponent } from '../books/books.component';
import { NotificationService } from '../shared/notification.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  user;
  Books;
  constructor(public _authService: AuthService, public _notificationService:NotificationService) { }

  ngOnInit() {
    
  

   
  }

  OpenMenu() {
    document.getElementById('collapsible').classList.toggle("in");
  }

  Logout() {
    this._authService.OnLogout();
  }

}
