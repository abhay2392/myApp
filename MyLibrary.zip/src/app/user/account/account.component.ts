import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {

  constructor(private _authService:AuthService) { }
  displayPic:string;
  user;
  ngOnInit() {
    this.displayPic="../assets/img/user.png";
    this.user = this._authService.getuserEmail();
  }

}
