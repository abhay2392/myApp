import { Component, OnInit } from '@angular/core';
import { BookService } from '../../books/books.service';
import { Book } from '../../books/book.model';
import { AuthService } from '../../auth/auth.service';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-userbooks',
  templateUrl: './userbooks.component.html',
  styleUrls: ['./userbooks.component.css']
})
export class UserbooksComponent implements OnInit {

  book: Book;
  Books : Book [];
  key: string;
  user: string;
  serachByParam;
  header;
  constructor(public _bookService: BookService, private _authService: AuthService, private route: ActivatedRoute, private toastr:ToastrService) {

  }

  bookList;
  SelectedFilter='title';
  SelectedSearch='title';
  ngOnInit() {

    this.key = this.route.snapshot.params['fav'];
    if(this.key == "Favorites"){
    this.header="My Favorites";
    }else{
      this.header="My Books";
    }

    console.log('No' + this.key);
    this.user = this._authService.getuserEmail();

    this._bookService.getData().snapshotChanges().subscribe(
      (response) => {

        if (this.key == "Favorites")
         {
          this.Books = [];
          response.forEach(element => {

            let dt=[];
            var y = element.payload.toJSON();
            y["$key"] = element.key;
            for(let i in y['likedBy'])
            {
              dt.push( y['likedBy'][i]);
            }
            let k=dt.indexOf(this.user);
            if(dt.indexOf(this.user) !==-1)
            {
            this.Books.push(y as Book);
            }

          });
      }

        else {



          this.Books = [];
          response.forEach(element => {
            var y = element.payload.toJSON();
            y["$key"] = element.key;
            if(y['allotedTo']==this.user)
            {
            this.Books.push(y as Book);
            }


          });
        }
      },
      (error) => (console.log(error))

    );








  }

  SelectedValueToSearch(data)
  {
 this.SelectedSearch=data.value;
  }

  
  SelectedValueToFilter(data)
  {
 this.SelectedFilter=data.value;
  }

  ReomveFromWishList(bookObj: Book,keyId:string) {
    let dt=[];
    for(let i in bookObj.likedBy)
            {
dt.push( bookObj.likedBy[i]);
            }

            dt.splice(dt.indexOf(this.user),1);
            bookObj.likedBy=dt;

    this._bookService.updateBook(bookObj, keyId);
    this.toastr.success("Book has removed from Favorites!", "Success!");
  }


}
