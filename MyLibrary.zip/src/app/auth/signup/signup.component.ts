import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private _authService: AuthService, private tostr: ToastrService) { }

  ngOnInit() {
  }

  signUp(signupForm: NgForm) {
    if (signupForm.valid) {
      this._authService.SignUp(signupForm.value.email, signupForm.value.password).then(
        res => this.tostr.success("Successfully signed up!", "Success!")
      ).catch(res => this.tostr.error("Something went wronng!", "Error!"));


    }
    else {
      this.tostr.error("please provide valid informations!", "Error!");
    }


  }

}
