import { Injectable } from '@angular/core';
import * as firebase from 'firebase';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class AuthService {

  constructor(private _route: Router) { }
  private loginBehavior = new BehaviorSubject(false);
  readonly loggedIn = this.loginBehavior.asObservable();

  token: string;
  userEmail: string;
  _isAdmin: boolean = false;

  SignUp(email: string, password: string) {
    return firebase.auth().createUserWithEmailAndPassword(email, password);

    //this.SignIn(email,password);
  }

  SignIn(email: string, password: string) {
    return firebase.auth().signInWithEmailAndPassword(email, password)
      

  }

  enrouteUser(email){
    if (email.substring(0, 5).toLowerCase() == "admin") {
      this._isAdmin = true;

    }
    this._route.navigate(["/booklist"]);
    this.userEmail = email;
    firebase.auth().currentUser.getIdToken()
      .then(
        (token: string) => this.token = token
      );
this.updateNotification();
    
  
  }

  updateNotification(){
    this.loginBehavior.next(true);
  }
  getuserEmail() {
    return this.userEmail;
  }

  getAuthKey() {
    firebase.auth().currentUser.getIdToken()
      .then(
        (token: string) => this.token = token
      );
    return this.token;

  }



  isAuthenticated() {
    return this.token != null;
  }

  OnLogout() {
    firebase.auth().signOut();
    this.token = null;
    this._isAdmin = false;
    this._route.navigate(["/"]);
  }

  isAdmin() {

    if (this.token != null && this._isAdmin) {
      return true;
    }
    else {
      return false;
    }
  }


}
