import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { validateConfig } from '@angular/router/src/config';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  constructor(private _authService: AuthService, private toastr: ToastrService) { }

  signinForm: FormGroup;
  ngOnInit() {
    this.signinForm = new FormGroup({
      "email": new FormControl(null, [Validators.required, Validators.email]),
      "password": new FormControl(null, Validators.required)

    });
  }

  SignIn() {
    if (this.signinForm.valid) {
      this._authService.SignIn(this.signinForm.value.email, this.signinForm.value.password).then(

        response => {

          this._authService.enrouteUser(this.signinForm.value.email);


        }

      ).catch(
        data =>this.toastr.error(data.message, "Error!")
      );
    }
    else {
      this.toastr.error("Please provide valid credentials!", "Error!");

    }
    // console.log(this.signinForm.value.email);
  }

}
