import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { BooksListComponent } from './books/books-list/books-list.component';
import { BooksComponent } from './books/books.component';
import { BooksDetailsComponent } from './books/books-details/books-details.component';
import { AddBooksComponent } from './books/add-books/add-books.component';
import { EditBooksComponent } from './books/edit-books/edit-books.component';
import { SigninComponent } from './auth/signin/signin.component';
import { SignupComponent } from './auth/signup/signup.component';
import { HeaderComponent } from './header/header.component';
import { HttpClientModule } from '@angular/common/http';
import { BookService } from "./books/books.service";
import { Routes, RouterModule } from "@angular/router";
import { DropdownDirective } from "./shared/dropdown.directive";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from './auth/auth.service';
import { AccountComponent } from './user/account/account.component';
import { UserbooksComponent } from './user/userbooks/userbooks.component';

import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { environment } from '../environments/environment';
import { TrimmerPipe } from './shared/trimmer.pipe';
import { SearchByPipe } from './shared/searchby.pipe';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReviewBookComponent } from './books/review-book/review-book.component';
import { AuthGuard } from './auth/auth-guard.service';
import { ConfigureComponent } from './admin/configure/configure.component';
import { SortByPipe } from './shared/sortby.pipe';
import { NotificationService } from './shared/notification.service';
import { NotificationComponent } from './notification/notification.component';

const appRoutes =
  [
    { path: "", component: SigninComponent },
    { path: "booklist", component: BooksListComponent, canActivate: [AuthGuard] },
    { path: "bookdetails/:key", component: BooksDetailsComponent, canActivate: [AuthGuard] },
    { path: "signup", component: SignupComponent },
    { path: "addbook", component: AddBooksComponent, canActivate: [AuthGuard] },
    { path: "myaccount", component: AccountComponent, canActivate: [AuthGuard] },
    { path: "userbooks", component: UserbooksComponent, canActivate: [AuthGuard] },
    { path: "userbooks/:fav", component: UserbooksComponent, canActivate: [AuthGuard] },
    { path: "editbook/:key", component: EditBooksComponent, canActivate: [AuthGuard] },
    { path: "config", component: ConfigureComponent, canActivate: [AuthGuard] }

  ]
@NgModule({
  declarations: [
    TrimmerPipe,
    SearchByPipe,
    SortByPipe,
    AppComponent,
    ConfigureComponent,
    BooksListComponent,
    BooksComponent,
    BooksDetailsComponent,
    AddBooksComponent,
    EditBooksComponent,
    SigninComponent,
    SignupComponent,
    HeaderComponent,
    DropdownDirective,
    AccountComponent,
    UserbooksComponent,
    ReviewBookComponent,
    ConfigureComponent,
    NotificationComponent


  ],
  imports: [
    ToastrModule.forRoot(),
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireDatabaseModule

  ],
  providers: [BookService, AuthService, AuthGuard, NotificationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
