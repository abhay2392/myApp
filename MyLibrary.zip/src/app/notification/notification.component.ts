import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { BookService } from '../books/books.service';
import { Subscription } from 'rxjs';
import { Book } from '../books/book.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {

  Books;
  book:Book;
  user;
  count;
  subscription: Subscription;
  message;

  ngOnInit(){
    this.subscription = this._authService.loggedIn.subscribe(message => this.GetNotifications());
  }

 

  


  constructor(private _authService:AuthService, private _bookService:BookService, private _tostr:ToastrService) { }

  GetNotificationsMessage(){
    if(this.count>0)
    this._tostr.error(this.count +" Book/s needs to be returned as due date is over.", "Attention!");
    }
  
  GetNotifications(){
    this.user = this._authService.getuserEmail();
   
    this._bookService.getData().snapshotChanges().subscribe(
      (response) => {       

        this.count=0;
          this.Books = [];
          response.forEach(element => {
            var y = element.payload.toJSON();
            y["$key"] = element.key;
            if(y['allotedTo']==this.user)
            { 
              
              this.book = y as Book;
              var today = new Date();
              var allocatedDate = new Date(this.book.allotedTill);

              if( allocatedDate< today) {
              //Do something..
              this.count++;
              }
            }
                
        });
      },

        
      (error) => (console.log(error)));
   
  }

}
