import { Component, OnInit } from '@angular/core';
import { BookService } from '../../books/books.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-configure',
  templateUrl: './configure.component.html',
  styleUrls: ['./configure.component.css']
})
export class ConfigureComponent implements OnInit {

  constructor(private _bookServivce: BookService, private toastr: ToastrService) { }
  bookCount;
  count: {};
  ngOnInit() {

    this._bookServivce.GetMaxBookCount().subscribe(
      (response) => {
        this.bookCount = response;
      },
      (error) => console.log(error)
    );
  }

  SetBookCountAllowed() {

    if (this.bookCount) {
      this._bookServivce.SetMaxBookCount(this.bookCount).subscribe(
        (response) => {
          this.toastr.success("Max. book count per user configred!", "Success!");

        },
        (error) => console.log(error)
      );

    } else {
      this.toastr.error("Please provide the count!", "Error!");
    }
  }

}
